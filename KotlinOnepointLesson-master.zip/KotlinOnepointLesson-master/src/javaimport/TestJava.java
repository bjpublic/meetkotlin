package javaimport;

/**
 * Created by snake on 17. 5. 23.
 */
public class TestJava {
    String getName(){
        return this.toString();
    };
}
