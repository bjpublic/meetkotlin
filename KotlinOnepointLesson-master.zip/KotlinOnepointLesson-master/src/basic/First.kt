package basic

/**
 * Created by snake on 17. 5. 21.
 */

fun main(args : Array<String>){
    println("안녕하세요. kotlin입니다")
    // 종결자 없이도 실행가능
}

