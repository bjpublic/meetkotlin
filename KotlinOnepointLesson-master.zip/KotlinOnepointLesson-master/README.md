# KotlinOnePointLesson - Quick Start  
First kotlin의 내용을 핵심만 정리한 프로젝트.

> **개발자를 위한 필요한 부분으로만 핵심정리**

First Kotlin은 입문자를 위해 과도한 한글표현을 사용했지만, 이 프로젝트는 평이한 개발자 수준의
소스코드로 이루어짐.

[Kotlin 공식페이지](https://kotlinlang.org/)
에서 레퍼런스를 참고합니다.

- [First Kotlin - 왕초보를 위한 한글식 표현](https://github.com/VintageAppMaker/FirstKotlin)
- play store [(kotlin 배우기 - github)](https://play.google.com/store/apps/details?id=com.psw.appbook.kotlin&hl=ko)


Contents:
---------

자세한 내용은 [wiki](https://github.com/VintageAppMaker/KotlinOnepointLesson/wiki)에서 관리합니다. 
